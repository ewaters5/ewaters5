(function ($, Drupal, once) {
  Drupal.behaviors.airtableFormSubmit = {
    attach: function (context, settings) {
      once('airtableFormSubmit', '#airtable-form', context).forEach(function (element) {
        $(element).on('submit', function (event) {
          event.preventDefault();

          // Gather form data and track validation state
          let isValid = true;
          let formData = {
            firstname: $('#airtable-firstname').val().trim(),
            lastname: $('#airtable-lastname').val().trim(),
            organization: $('#airtable-organization').val().trim(),
            email: $('#airtable-email').val().trim()
          };

          // Validate each field and show/hide the invalid-feedback message accordingly
          if (!formData.firstname) {
            $('#airtable-firstname').addClass('is-invalid');
            $('#airtable-firstname').siblings('.invalid-feedback').show();
            isValid = false;
          } else {
            $('#airtable-firstname').removeClass('is-invalid');
            $('#airtable-firstname').siblings('.invalid-feedback').hide();
          }

          if (!formData.lastname) {
            $('#airtable-lastname').addClass('is-invalid');
            $('#airtable-lastname').siblings('.invalid-feedback').show();
            isValid = false;
          } else {
            $('#airtable-lastname').removeClass('is-invalid');
            $('#airtable-lastname').siblings('.invalid-feedback').hide();
          }

          if (!formData.organization) {
            $('#airtable-organization').addClass('is-invalid');
            $('#airtable-organization').siblings('.invalid-feedback').show();
            isValid = false;
          } else {
            $('#airtable-organization').removeClass('is-invalid');
            $('#airtable-organization').siblings('.invalid-feedback').hide();
          }

          if (!formData.email) {
            $('#airtable-email').addClass('is-invalid');
            $('#airtable-email').siblings('.invalid-feedback').show();
            isValid = false;
          } else {
            $('#airtable-email').removeClass('is-invalid');
            $('#airtable-email').siblings('.invalid-feedback').hide();
          }

          // If the form is not valid, stop the submission
          if (!isValid) {
            return;
          }

          // Proceed with the AJAX submission if the form is valid
          $.ajax({
            url: Drupal.url('airtable_form_submit/capture'),
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
              // Use toast notifications
              if (response.success) {
                // Assuming you have a toast library loaded
                toastr.success(response.message);
                $('#airtable-form')[0].reset(); // Clear the form fields
              } else {
                toastr.error(response.message);
              }
            
              // Use js alert notifications
              // if (response.success) {
              //   // Clear the form fields
              //   $('#airtable-form')[0].reset();

              //   // Hide all invalid feedback after successful submission
              //   $('.invalid-feedback').hide();
              //   $('.form-control').removeClass('is-invalid');

              //   // Display a success message
              //   $('#airtable-form').before('<div class="alert alert-success airtable-form-message fullwidth">' + response.message + '</div>');
              // } else {
              //   // Display an error message
              //   $('#airtable-form').before('<div class="alert alert-danger airtable-form-message fullwidth">' + response.message + '</div>');
              // }

            },
            error: function (xhr, status, error) {
              // Display a general error message
              $('#airtable-form').before('<div class="alert alert-danger airtable-form-message fullwidth">An error occurred: ' + error + '</div>');
            }
          });
        });
      });
    }
  };
})(jQuery, Drupal, once);
