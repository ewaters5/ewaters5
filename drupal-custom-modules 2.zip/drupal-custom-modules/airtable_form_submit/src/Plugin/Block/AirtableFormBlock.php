<?php

namespace Drupal\airtable_form_submit\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a block with a simple form.
 *
 * @Block(
 *   id = "airtable_form_block",
 *   admin_label = @Translation("Airtable Form Block"),
 * )
 */
class AirtableFormBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'inline_template',
      '#template' => '
        <form class="airtable-form" id="airtable-form">
          <div class="form-group">
            <label for="airtable-firstname" class="sr-only">First Name</label>
            <input type="text" id="airtable-firstname" name="airtable-firstname" placeholder="First Name" class="form-control">
            <div class="invalid-feedback">
              Please enter first name.
            </div>
          </div>
          <div class="form-group">
            <label for="airtable-lastname" class="sr-only">Last Name</label>
            <input type="text" id="airtable-lastname" name="airtable-lastname" placeholder="Last Name" class="form-control">
            <div class="invalid-feedback">
              Please enter last name.
            </div>
          </div>
          <div class="form-group">
            <label for="airtable-organization" class="sr-only">Organization</label>
            <input type="text" id="airtable-organization" name="airtable-organization" placeholder="Organization" class="form-control">
            <div class="invalid-feedback">
              Please enter organization.
            </div>
          </div>
          <div class="form-group">
            <label for="airtable-email" class="sr-only">E-mail</label>
            <input type="email" id="airtable-email" name="airtable-email" placeholder="E-mail" class="form-control">
            <div class="invalid-feedback">
              Please enter email.
            </div>
          </div>
          <button type="submit" class="btn btn-primary" id="airtable-button-submit">Join</button>
        </form>
      ',
      '#attached' => [
        'library' => [
          'airtable_form_submit/airtable_form_submit_js',
          'airtable_form_submit/airtable_form_submit_styles', // Attach the CSS library
        ],
      ],
    ];
  }
}
