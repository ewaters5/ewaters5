<?php 

namespace Drupal\airtable_form_submit\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\airtable_form_submit\Service\AirtableApiService;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Controller to handle Airtable form submissions.
 */
class AirtableFormController extends ControllerBase {

  protected $airtableApiService;

  /**
   * Constructs a new AirtableFormController.
   */
  public function __construct(AirtableApiService $airtableApiService) {
    $this->airtableApiService = $airtableApiService;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('airtable_form_submit.airtable_api_service')
    );
  }

  /**
   * Handles the form submission.
   */
  public function capture(Request $request) {
    // Extract form data
    $firstname = $request->get('firstname');
    $lastname = $request->get('lastname');
    $organization = $request->get('organization');
    $email = $request->get('email');

    // Prepare data for Airtable
    $data = [
      'First Name' => $firstname,
      'Last Name' => $lastname,
      'Organization' => $organization,
      'Email' => $email,
    ];

    // Send the data to Airtable
    $response = $this->airtableApiService->createRecord($data);

    if ($response) {
      return new JsonResponse(['success' => true, 'message' => 'Thanks for signing up!']);
    } else {
      return new JsonResponse(['success' => false, 'message' => 'Submission error.'], 500);
    }
  }
}
