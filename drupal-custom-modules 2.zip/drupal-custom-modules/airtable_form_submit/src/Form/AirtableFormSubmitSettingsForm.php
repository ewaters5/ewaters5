<?php

namespace Drupal\airtable_form_submit\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Configure Airtable settings for this site.
 */
class AirtableFormSubmitSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['airtable_form_submit.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'airtable_form_submit_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('airtable_form_submit.settings');

    $form['base_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Airtable Base ID'),
      '#default_value' => $config->get('base_id'),
      '#description' => $this->t('Enter the ID of your Airtable base.'),
      '#required' => TRUE,
    ];

    $form['table_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Airtable Table ID'),
      '#default_value' => $config->get('table_name'),
      '#description' => $this->t('Enter the ID of the table within the Airtable base.'),
      '#required' => TRUE,
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('airtable_form_submit.settings')
      ->set('base_id', $form_state->getValue('base_id'))
      ->set('table_name', $form_state->getValue('table_name'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
