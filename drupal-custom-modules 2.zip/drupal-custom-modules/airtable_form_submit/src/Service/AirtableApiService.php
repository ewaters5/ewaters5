<?php 

namespace Drupal\airtable_form_submit\Service;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Service to interact with Airtable API using a personal access token from a secrets file or local settings.
 */
class AirtableApiService {

  private $accessToken;
  private $baseId;
  private $tableName;
  private $httpClient;

  public function __construct(ClientInterface $httpClient, ConfigFactoryInterface $configFactory) {
    // Output the value of the DCK_STACK environment variable for debugging
    $stackEnv = getenv('DCK_STACK');
    // \Drupal::logger('airtable_form_submit')->debug('DCK_STACK environment variable value: @value', [
    //   '@value' => $stackEnv,
    // ]);

    // Determine the environment and load the appropriate access token
    if ($this->isLocalEnvironment($stackEnv)) {
      // Load the access token from the local settings.docksal.php file
      $this->accessToken = getenv('AIRTABLE_ACCESS_TOKEN_LOCAL');
      // \Drupal::logger('airtable_form_submit')->debug('Using local access token.');
    } else {
      // Load the access token from the secrets file in other environments
      $secret = "/var/www/" . $stackEnv . "-secret.php";
      $sec_values = (require $secret); 
      $this->accessToken = $sec_values['airtable']['accesstoken'];
      // \Drupal::logger('airtable_form_submit')->debug('Using secret file access token.');
    }

    // Load the configuration values for base_id and table_name
    $config = $configFactory->get('airtable_form_submit.settings');
    $this->baseId = $config->get('base_id');
    $this->tableName = $config->get('table_name');

    // Log if base_id or table_name is missing
    if (!$this->baseId || !$this->tableName) {
      \Drupal::logger('airtable_form_submit')->error('Missing base_id or table_name in configuration.');
      return;
    }

    $this->httpClient = $httpClient;
  }

  /**
   * Determines if the current environment is the local environment.
   *
   * @param string $stackEnv
   *   The value of the DCK_STACK environment variable.
   *
   * @return bool
   *   Returns TRUE if in the local environment, FALSE otherwise.
   */
  private function isLocalEnvironment($stackEnv) {
    // Consider empty DCK_STACK or 'local' as a local environment
    return empty($stackEnv) || $stackEnv === 'local';
  }

  /**
   * Sends data to Airtable to create a new record.
   *
   * @param array $fields
   *   An associative array representing a single record's fields and their values.
   *   Example: ['Name' => 'John Doe', 'Email' => 'john.doe@example.com']
   *
   * @param bool $typecast
   *   Optional boolean to enable typecasting of data.
   *
   * @return array|bool
   *   Returns the API response as an associative array on success, or FALSE on failure.
   */
  public function createRecord(array $fields, $typecast = false) {
    $endpoint = sprintf('https://api.airtable.com/v0/%s/%s', $this->baseId, $this->tableName);

    // \Drupal::logger('airtable_form_submit')->debug('Sending request to endpoint: @endpoint with token: @token', [
    //   '@endpoint' => $endpoint,
    //   '@token' => substr($this->accessToken, 0, 5) . '...' // Log only a portion of the token for security
    // ]);

    // Prepare the request body
    $body = [
      'fields' => $fields,
      'typecast' => $typecast,
    ];

    try {
      $response = $this->httpClient->request('POST', $endpoint, [
        'headers' => [
          'Authorization' => 'Bearer ' . $this->accessToken,
          'Content-Type' => 'application/json',
        ],
        'json' => $body,
      ]);

      return json_decode($response->getBody()->getContents(), true);
    } catch (RequestException $e) {
      \Drupal::logger('airtable_form_submit')->error('Request failed: @message', [
        '@message' => $e->getMessage(),
      ]);
      return false;
    }
  }

  /**
   * Sends data to Airtable to create multiple records.
   *
   * @param array $records
   *   An array of associative arrays representing multiple records.
   *   Each record should be an associative array with field names or field IDs as keys.
   *
   * @param bool $typecast
   *   Optional boolean to enable typecasting of data.
   *
   * @return array|bool
   *   Returns the API response as an associative array on success, or FALSE on failure.
   */
  public function createRecords(array $records, $typecast = false) {
    $endpoint = sprintf('https://api.airtable.com/v0/%s/%s', $this->baseId, $this->tableName);

    // \Drupal::logger('airtable_form_submit')->debug('Sending request to endpoint: @endpoint with token: @token', [
    //   '@endpoint' => $endpoint,
    //   '@token' => substr($this->accessToken, 0, 5) . '...' // Log only a portion of the token for security
    // ]);

    // Prepare the request body
    $body = [
      'records' => array_map(function($record) {
        return ['fields' => $record];
      }, $records),
      'typecast' => $typecast,
    ];

    try {
      $response = $this->httpClient->request('POST', $endpoint, [
        'headers' => [
          'Authorization' => 'Bearer ' . $this->accessToken,
          'Content-Type' => 'application/json',
        ],
        'json' => $body,
      ]);

      return json_decode($response->getBody()->getContents(), true);
    } catch (RequestException $e) {
      \Drupal::logger('airtable_form_submit')->error('Request failed: @message', [
        '@message' => $e->getMessage(),
      ]);
      return false;
    }
  }
}
