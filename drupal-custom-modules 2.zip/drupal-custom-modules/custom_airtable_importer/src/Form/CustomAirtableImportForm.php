<?php

/**
 * 
 * @author Eric Waters <ewaters@air.org>
 * 
 * Custom importer to pull data from ASN EdTech Library (Airtable) 
 * Creates a form button that instantiates and calls the importer service.
 */

 namespace Drupal\custom_airtable_importer\Form;

 use Drupal\Core\Form\FormBase;
 use Drupal\Core\Form\FormStateInterface;
 use Symfony\Component\DependencyInjection\ContainerInterface;
 use Drupal\custom_airtable_importer\AirtableImporterService;
 use Drupal\Component\Render\FormattableMarkup;
 use Drupal\Core\Url;
 use Drupal\Core\Ajax\AjaxResponse;
 use Drupal\Core\Ajax\HtmlCommand;
 use Drupal\Core\Ajax\ReplaceCommand;
 
 class CustomAirtableImportForm extends FormBase {
 
   protected $airtableImporterService;
 
   public function __construct(AirtableImporterService $airtableImporterService) {
     $this->airtableImporterService = $airtableImporterService;
   }
 
   public static function create(ContainerInterface $container) {
     return new static(
       $container->get('custom_airtable_importer.airtable_importer')
     );
   }
 
   public function getFormId() {
     return 'custom_airtable_import_form';
   }
 
   public function buildForm(array $form, FormStateInterface $form_state) {
    $form['data_import_manager'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Data Import Manager'),
    ];
  
    $form['data_import_manager']['description'] = [
      '#type' => 'item',
      '#markup' => $this->t('Click the button to import data from Airtable to Drupal nodes. This will delete all existing EdTech Library resources from the site and import a fresh copy of all current resources from Airtable.'),
    ];
  
    $form['data_import_manager']['import_button'] = [
      '#type' => 'submit',
      '#value' => $this->t('Import Data'),
      '#button_type' => 'primary',
      '#ajax' => [
        'callback' => [$this, 'submitFormAjaxCallback'],
        'event' => 'click',
        'progress' => [
          'type' => 'throbber',
          'message' => $this->t('Importing data...'),
        ],
      ],
    ];
  
    return $form;
  }
  
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Import data using the AirtableImporterService (no changes needed here).
  }
  
  public function submitFormAjaxCallback(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
  
    // Perform the import using the AirtableImporterService.
    $this->airtableImporterService->import();
  
    // Create an HTML link to the admin page.
    $admin_url = Url::fromRoute('system.admin_content', ['type' => 'edtech_library_resource']);
    $admin_link = \Drupal\Core\Link::fromTextAndUrl($this->t('View imported resources in the content area.'), $admin_url);
  
    // Get the URL for the admin page.
    $admin_url_rendered = $admin_link->getUrl()->toString();
  
    // Display success message with the link as HTML using an AJAX command.
    $message = $this->t('<div class="messages messages--status">Data imported successfully from Airtable. <a href="@link">View imported resources in the content area.</a></div>', ['@link' => $admin_url_rendered]);
    $response->addCommand(new HtmlCommand('#edit-description', $message));
  
    return $response;
  }
}