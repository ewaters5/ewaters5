<?php

/**
 * @file
 * Contains \Drupal\custom_airtable_importer\AirtableImporterService.
 * 
 * @author Eric Waters <ewaters@air.org>
 * 
 * Custom importer to pull data from ASN EdTech Library (Airtable) 
 * https://airtable.com/appnj0ZaKCyPl0DKb/tblTffwBnyDNcFVW1/viw7h5RqFUbVP0lcw
 */

namespace Drupal\custom_airtable_importer;

use Drupal\taxonomy\Entity\Term;
use Drupal\node\Entity\Node;
use GuzzleHttp\ClientInterface;

class AirtableImporterService {

  private $access_token;
  private $base;
  private $table;
  private $httpClient;

  public function __construct(ClientInterface $httpClient) {

    $STACK=getenv('DCK_STACK');
    $secret = "/var/www/" . $STACK. "-secret.php";
    $sec_values = (require $secret); 
    $access_token = $sec_values['airtable']['accesstoken'];

    $this->access_token = $access_token;
    $this->base = 'appnj0ZaKCyPl0DKb';
    $this->table = 'tblTffwBnyDNcFVW1';
    $this->httpClient = $httpClient;
  }

  public function import() {

    // Delete all existing nodes of type 'edtech_library_resource'.
    $this->deleteAllNodes();

    // Delete all terms from the referenced vocabularies.
    $this->deleteAllTermsFromVocabulary('edtech_library_resource_type');
    $this->deleteAllTermsFromVocabulary('edtech_library_resource_category');
    $this->deleteAllTermsFromVocabulary('edtech_library_resource_format');

    $data = $this->getDataFromAirtable();

    foreach ($data as $item) {
      $this->createOrUpdateNode($item);
    }
  }

  private function getDataFromAirtable() {
    $url = "https://api.airtable.com/v0/$this->base/$this->table";
    $headers = [
      'Authorization' => 'Bearer ' . $this->access_token,
      'Content-Type' => 'application/json',
    ];

    $query_params = [
        // Add your query parameters here.
        // For example, to filter records based on a field value:
        // 'filterByFormula' => 'Your_Filter_Formula',
        // 'maxRecords' => 10, // Limit the number of records to retrieve.
        // 'sort' => [['field' => 'Field_Name', 'direction' => 'asc']],
        // 'returnFieldsByFieldId' => 'true',
      ];
    
      $response = $this->httpClient->request('GET', $url, [
        'headers' => $headers,
        'query' => $query_params,
      ]);
    
      $data = json_decode($response->getBody(), TRUE);

    return isset($data['records']) ? $data['records'] : [];
  }

  private function createOrUpdateNode($data) {
    $fields = $data['fields'];
    $node = Node::create([
      'type' => 'edtech_library_resource',
      'title' => $fields['Title of Resource'], // Adjust the field name accordingly.
      'field_description' => $fields['Resource Description'], // Adjust the field name accordingly.
      'field_resource_url' => $fields['Resource URL'], // Adjust the field name accordingly.
      'field_publication_year' => $fields['Publication Year'], // Adjust the field name accordingly.
      'field_resource_type' => $fields['Resource Type'], // Adjust the field name accordingly.
      'field_category' => $fields['Category'], // Adjust the field name accordingly.
      'field_format' => $fields['Format'], // Adjust the field name accordingly.
      'field_accessibility' => $fields['Accessibility'], // Adjust the field name accordingly.
      'field_tags_edtech' => $fields['Tags'], // Adjust the field name accordingly.
      // Map other fields...
    ]);

    // if (isset($data['fields']['title'])) {
    //     $node->set('title', $data['fields']['title']);
    //   }    

    // $node->save();

    // Process taxonomy fields with their respective vocabularies
    $taxonomy_fields = [
        'field_resource_type' => 'edtech_library_resource_type', // Replace with your field machine name => taxonomy machine name. (single-select)
        'field_category' => 'edtech_library_resource_category', // Replace with your field machine name => taxonomy machine name. (multi-select)
        'field_format' => 'edtech_library_resource_format', // Replace with your field machine name => taxonomy machine name. (single-select)
      ];
  
    //   foreach ($taxonomy_fields as $field_name => $vocabulary) {
    //     if (isset($data['fields'][$field_name])) {
    //       $this->processTaxonomyField($field_name, $vocabulary, $data['fields'][$field_name]);
    //     }
    // //   }
        if (isset($data['fields']['Resource Type'])) {
          $newTerms = $this->processTaxonomyField('field_resource_type', 'edtech_library_resource_type', $data['fields']['Resource Type']);
          $node->set('field_resource_type', $newTerms);
        }
        if (isset($data['fields']['Category'])) {
          $newTerms = $this->processTaxonomyField('field_category', 'edtech_library_resource_category', $data['fields']['Category']);
          $node->set('field_category', $newTerms);
        }
        if (isset($data['fields']['Format'])) {
            $newTerms = $this->processTaxonomyField('field_format', 'edtech_library_resource_format', $data['fields']['Format']);
            $node->set('field_format', $newTerms);
          }

        $node->save();

  }
  
  private function processTaxonomyField($field_name, $vocabulary, $values) {
    // Remove all existing terms from the vocabulary.

    $term_ids = [];

    if (is_array($values)) {
        foreach ($values as $value) {
            $term = $this->createOrUpdateTaxonomyTerm($vocabulary, $value);
            if ($term) {
                $term_ids[] = $term;
            }
        }
    } else {
        $term = $this->createOrUpdateTaxonomyTerm($vocabulary, $values);
        if ($term) {
            $term_ids[] = $term;
        }
    }

    return $term_ids;
}

private function deleteAllTermsFromVocabulary($vocabulary) {
    $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')
        ->loadByProperties(['vid' => $vocabulary]);

    foreach ($terms as $term) {
        $term->delete();
    }
}

        
        // if ($node) {
        //     $node->set('field_resource_type', $term_ids);
        // }



  private function createOrUpdateTaxonomyTerm($vocabulary, $value) {
     // Load taxonomy term by properties (name and vocabulary ID).
     $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')
     ->loadByProperties(['name' => $value, 'vid' => $vocabulary]);
  
     if (!empty($terms)) {
        $term = reset($terms);
        return $term->id();
     } else {
      // Create a new taxonomy term.
      $term = Term::create([
        'vid' => $vocabulary,
        'name' => $value,
      ]);
  
      $term->save();
      return $term->id();
    }
  }

  private function deleteAllNodes() {
    // Load all nodes of the 'edtech_library_resource' type.
    $nodes = \Drupal::entityTypeManager()
      ->getStorage('node')
      ->loadByProperties(['type' => 'edtech_library_resource']);

    // Delete each node.
    foreach ($nodes as $node) {
      $node->delete();
    }
  }
}