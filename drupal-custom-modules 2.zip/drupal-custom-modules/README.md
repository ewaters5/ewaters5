# Drupal Custom Modules Repository

## Overview

This repository contains a collection of Drupal custom modules developed by AIR developers to enhance and extend the functionality of Drupal websites.

## Modules

- [Show Context](./show_context/README.md): A module to display active contexts.
- [Admin Styles](./admin_styles/README.md): A module to add custom CSS styles and custom blocks into your Drupal admin theme without overriding the theme itself.
- [Custom Airtable Importer](./custom_airtable_importer/README.md): A module for importing data from airtable into Drupal nodes.

## Requirements

- Drupal Core: ^10 (may vary by module)
- Additional dependencies are listed in each module's README.

## Installation

1. Clone this repository or download the desired module.
2. Place the module in your Drupal `modules` directory.
3. Enable the module via the Drupal admin interface or using Drush.

## Usage

Refer to each module's individual README for usage instructions.

## Contributing

If you have a custom module you think other developers could use or customize for another site, please add it here! If so, please update this README.md file with your module in the list above and add it to this repo.

Also, feel free to submit issues or pull requests for improvements, bug fixes, or new features.

1. Fork the repository.
2. Create a new branch for your feature or fix.
3. Submit a pull request.
