<?php

namespace Drupal\show_context\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\context\ContextManager;

/**
 * Provides a 'ActiveContexts' block.
 *
 * @Block(
 *   id = "active_contexts",
 *   admin_label = @Translation("Active Contexts"),
 * )
 */
class ActiveContexts extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The context manager service.
   *
   * @var \Drupal\context\ContextManager
   */
  protected $contextManager;

  /**
   * Constructs a new ActiveContexts block.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\context\ContextManager $context_manager
   *   The context manager service.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, ContextManager $context_manager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->contextManager = $context_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('context.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $active_contexts = $this->contextManager->getActiveContexts();
    $context_names = [];

    foreach ($active_contexts as $context) {
      $context_names[] = $context->getName();
    }

    return [
      '#markup' => implode('<br/> ', $context_names),
    ];
  }

}
