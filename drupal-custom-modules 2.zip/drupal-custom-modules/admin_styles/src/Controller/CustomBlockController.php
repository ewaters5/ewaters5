<?php

namespace Drupal\admin_styles\Controller;

use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Controller\ControllerBase;

class CustomBlockController extends ControllerBase {

  public function renderBlock() {
    // Load your custom block.
    $block_entity = $this->entityTypeManager()->getStorage('block_content')->load('43'); //replace with your custom block id
    
    // Get the machine name (ID) of the block.
    $block_machine_name = $block_entity->id();
    
    // Generate the unique ID.
    $unique_id = 'admin-block-' . $block_machine_name;

    // Build and render the block.
    $block = $this->entityTypeManager()
      ->getViewBuilder('block_content')
      ->view($block_entity);

    $rendered_block = \Drupal::service('renderer')->render($block);

    // Return the rendered HTML and unique ID as a JSON object.
    return new JsonResponse([
      'html' => $rendered_block,
      'unique_id' => $unique_id,
    ]);
  }
}
