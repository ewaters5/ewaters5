(function ($, Drupal) {
    Drupal.behaviors.insertCustomBlock = {
      attach: function (context, settings) {
        $.ajax({
          url: '/admin_styles/custom_block',
          method: 'GET',
          dataType: 'json',
          success: function(response) {
            // Insert the block into the beginning of the specific <div>.
            const blockElement = $(response.html);
            blockElement.attr('id', response.unique_id)  // Set the unique ID dynamically
                       .addClass('admin-blocks');  // Add the class "admin-blocks"
            //specify the enclosing element to target
            $('.layout-region-node-main', context).once('insertCustomBlock').prepend(blockElement);
          }
        });
      }
    };
  })(jQuery, Drupal);
  