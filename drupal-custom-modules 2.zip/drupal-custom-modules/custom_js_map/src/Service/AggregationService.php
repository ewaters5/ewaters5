<?php

namespace Drupal\custom_js_map\Service;

use Drupal\views\ViewExecutable;
use Drupal\taxonomy\Entity\Term;

class AggregationService {
  public function aggregateViewResults(ViewExecutable $view) {
    // Temporary storage for aggregated terms across all results.
    $allAggregatedTerms = [];

    foreach ($view->result as $resultIndex => $result) {
      // Check for the related entity loaded via the 'field_states' relationship.
      if (isset($result->_relationship_entities['field_states'])) {
        $relatedEntity = $result->_relationship_entities['field_states'];

        if ($relatedEntity && $relatedEntity->hasField('field_2_states') && !$relatedEntity->get('field_2_states')->isEmpty()) {
          $terms = $relatedEntity->get('field_2_states')->referencedEntities();
          foreach ($terms as $term) {
            // Use term ID as the key to ensure uniqueness.
            $allAggregatedTerms[$term->id()] = $term->label(); // Use label() method for term name.
          }
        }
      }
    }

    // Convert aggregated terms to a string.
    $termsString = implode(', ', array_unique(array_values($allAggregatedTerms)));

    // Apply the aggregated string to each result in a way that affects view output.
    foreach ($view->result as $resultIndex => $result) {
      // Modify the result to include the aggregated terms string.
      // This assumes 'nothing' is a field that can be directly manipulated like this;
      // adjust based on your view's actual configuration.
      if (isset($view->field['nothing'])) {
        $view->field['nothing']->options['alter']['text'] = $termsString;
      }
    }
  }
}
