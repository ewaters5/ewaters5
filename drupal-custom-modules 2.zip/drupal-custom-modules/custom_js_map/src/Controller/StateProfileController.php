<?php

namespace Drupal\custom_js_map\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Render\RendererInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\views\Views;

class StateProfileController extends ControllerBase {

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * Constructs a new StateProfileController.
   *
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer service.
   */
  public function __construct(RendererInterface $renderer) {
    $this->renderer = $renderer;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('renderer')
    );
  }

  /**
   * Updates the view based on the given parameters.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The current request.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   A JSON response with the rendered view.
   */
  public function updateView(Request $request) {
    $logger = \Drupal::logger('custom_module');

    // Retrieve and process each parameter from the query
    // Ensuring that 'all' is used if parameters are empty or not present
    $state = $request->query->get('state', 'all');
    $topics = $request->query->get('topics', '');
    $targets = $request->query->get('targets', '');
    $grades = $request->query->get('grades', '');

    // Check if the parameters are empty and default them to 'all' if so
    $topics = empty($topics) ? 'all' : implode(',', (array) $topics);
    $targets = empty($targets) ? 'all' : implode(',', (array) $targets);
    $grades = empty($grades) ? 'all' : implode(',', (array) $grades);

    // Log the received and processed parameters
    $logger->info('Received filters - State: @state, Topics: @topics, Targets: @targets, Grades: @grades', [
        '@state' => $state,
        '@topics' => $topics,
        '@targets' => $targets,
        '@grades' => $grades
    ]);

    // Set up arguments for the view in the expected order -- order of the contextual filters
    $arguments = [$state, $topics, $targets, $grades];
    $logger->info('Prepared arguments for view: @args', ['@args' => implode(', ', $arguments)]);
    $arg_string = implode(', ', $arguments);
    $logger->info('Argument string: @args2', ['@args2' => $arg_string]);

    $view = Views::getView('state_studies');
    if ($view) {
        $view->setDisplay('block_1');
        $view->setArguments($arguments);
        $view->preExecute();
        $view->execute();
    
        if ($view->result) {
            // Count the number of nodes
            $nodeCount = count($view->result);
    
            if($arg_string == 'all, all, all, all'){ //no filter selected
                return new JsonResponse(['content' => 'Select a filter to explore.', 'nodeCount' => $nodeCount], 200);
            } else {
                $render_array = $view->buildRenderable('block_1', $arguments);
                $rendered_view = \Drupal::service('renderer')->renderRoot($render_array);
                
                // Extract all state data from each node, flatten the array, and remove duplicates
                $allStates = [];
                foreach ($view->result as $row) {
                    $node = $row->_entity;
                    foreach ($node->field_states as $state) {
                        $allStates[] = [
                            'tid' => $state->target_id,
                            'name' => $state->entity->label()
                        ];
                    }
                }
                // Remove duplicates based on 'tid'
                $uniqueStates = array_reduce($allStates, function($carry, $item) {
                    $carry[$item['tid']] = $item;
                    return $carry;
                }, []);
    
                return new JsonResponse(['content' => $rendered_view, 'stateData' => array_values($allStates), 'nodeCount' => $nodeCount]);
            }
        } else {
            $logger->info('View executed but no results found.');
            return new JsonResponse(['content' => 'No results found.', 'stateData' => [], 'nodeCount' => 0], 204);
        }
    } else {
        $logger->error('View not found.');
        return new JsonResponse(['error' => 'View not found.'], 404);
    }
    
  }

}
