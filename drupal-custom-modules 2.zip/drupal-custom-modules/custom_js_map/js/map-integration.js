// Ensure this script is deferred or placed at the bottom of the HTML body,
// or that it's executed after the map has been fully initialized.
var map; // Assume this is assigned elsewhere

jQuery(document).ready(function($) {
    // Debugging: Confirm entry into script
    //console.log("map-integration.js loaded");


    function updateStateCounts() {
        //console.log("Fetching state counts...");
        $.ajax({
            url: '/api/states', // Confirm this endpoint is correct
            method: 'GET',
            success: function(data) {
                //console.log("Received data (/api/states):", data); // Debugging: Log received data
    
                // Iterate over all states in the map configuration
                Object.entries(stateNameToIdMap).forEach(([stateName, stateId]) => {
                    // Find the corresponding state in the AJAX response
                    const stateData = data.find(state => state.name.trim() === stateName);
                    const activityCount = stateData ? stateData.field_states : "0"; // Default to "0" if state not present in response
                    
                    if (stateId && map) {
                        // Update comment with activity count
                        map.setStateAttr(stateId, 'comment', "<div class='state-tooltip'><div class='state-tooltip-title'>" + stateName + "</div><div class='state-tooltip-count'>Total # of studies: " + activityCount + "</div><div class='state-tooltip-link'>See matching studies</div><div class='state-tooltip-link'>See ESSER Plan</div></div>");
                    }
                });
    
                //console.log("State counts updated successfully.");
            },
            error: function() {
                console.error("Failed to fetch or update state counts.");
            }
        });
    }
    
    // Confirm map is initialized and accessible at this point
    if (map) {
        // updateStateCounts();
    } else {
        console.error("Map not initialized when trying to update state counts.");
    }
});
