jQuery(document).ready(function($) {

  // Function to check and replace the target <g> element
  function checkAndReplaceTargetGElement(selected) {
    var svgMapContainers = $('.fm-map-container svg');
    if (svgMapContainers.length > 0) {
      //console.log("SVG map container found.");
      var gElement = document.querySelector('g[transform="matrix(2.4,0,0,2.4,474,289)"]');
        replaceTargetGElement(gElement, selected);
    } else {
      //console.log("SVG map container not found.");
    }
  }

  //function to add PR to map
  function replaceTargetGElement(gElement, selected) {

    // Create a new path element for the square
    var square = document.createElementNS('http://www.w3.org/2000/svg', 'rect');

    // Calculate the center and size of the square based on the circle's attributes
    var circleCX = 0; // Circle's center X (cx attribute of the circle)
    var circleCY = 0; // Circle's center Y (cy attribute of the circle)
    var squareSideLength = 10.4; // Example side length of the square, adjusted for the transformation scale

    // Set the square's attributes
    square.setAttribute('x', circleCX - squareSideLength / 2);
    square.setAttribute('y', circleCY - squareSideLength / 2);
    square.setAttribute('width', squareSideLength);
    square.setAttribute('height', squareSideLength);
    if(selected){
      square.setAttribute('fill', '#8352B7'); // Make the square transparent
      square.setAttribute('stroke', '#8352B7'); // Optional: add a stroke to visualize the square's border
    } else {
      square.setAttribute('fill', '#D1D5DB'); // Make the square transparent
      square.setAttribute('stroke', '#D1D5DB'); // Optional: add a stroke to visualize the square's border
    }
    square.setAttribute('stroke-width', '0.2882420091324201');
    square.classList.add("hoverable");
    square.classList.add("pr-tile");

    // square.setAttribute('pointer-events', 'none'); // Ensure the square does not capture mouse events

    // Append the square to the same <g> element as the circle
    gElement.appendChild(square);
    //console.log("New square element added.");

    // Find the sibling text element and disable pointer events
    var siblingTextElement = gElement.nextElementSibling;
    if (siblingTextElement && siblingTextElement.tagName.toLowerCase() === 'text') {
      siblingTextElement.setAttribute('pointer-events', 'none');
      //console.log("Pointer events disabled on sibling text element.");
    }  
  }

  // Continuously check if the map has loaded every 100ms
  var checkMapLoaded = setInterval(function() {
    if ($('.fm-map-container svg').length > 0) {
      clearInterval(checkMapLoaded);
      checkAndReplaceTargetGElement();
    }
  }, 100);

  // Resets and fetches state data to update the map_data array
  function resetAndFetchStateData() {
    //console.log("Fetching state data to update map configuration.");

    // Fetch fresh state data and update the map directly
    $.ajax({
        url: '/api/states',
        success: function(data) {
            data.forEach(function(item) {
              if (item.name.trim() === "Puerto Rico"){
                // //console.log("pointKey: p0-> item.tid: " + item.tid);
                // Update the tid for PR
                map.setPointAttr("p0", {
                  tid: item.tid, // Update the tid for the state
                  comment: "" // disable the tooltip initially
                });
              } else {
                // Find the corresponding state key in map_cfg.map_data
                let stateKey = Object.keys(map_cfg.map_data).find(key => map_cfg.map_data[key].name === item.name.trim());
                // //console.log("stateKey: " + stateKey + "-> item.tid: " + item.tid);
                if (stateKey) {
                    // Update the tid and potentially other attributes directly on the map
                    map.setStateAttr(stateKey, {
                        tid: item.tid, // Update the tid for the state
                        comment: "" // disable the tooltip initially
                    });
                }
              }
            });

            //console.log("Map attributes updated dynamically with new state TIDs.");
            // printKeyAndAttr(map_cfg.map_data, 'tid');
        },
        error: function() {
            console.error("Failed to fetch state data.");
        }
    });
  }
  resetAndFetchStateData(); // resets map_data array on page reload

  // Function to initialize event listeners
  function initializeFilterWidgetListeners() {
    // Accordion toggle for each filter header
    $('.filter-widget .filter-header h4').off('click').on('click', function() {
      $(this).closest('.filter-header').siblings('.filter-options').slideToggle();
      //console.log("Toggle filter options");
    });

    // Toggle for state filter options
    $('.filter-widget-states .filter-header-state').off('click').on('click', function() {
      // Toggle the visibility of the filter options
      $(this).find('.filter-options').slideToggle();
      //console.log("State filter options toggled.");
    });

    // Filter option change for checkboxes
    $('.filter-options input[type=checkbox]').off('change').on('change', function() {
      if (!isClearingAllFilters) { // Only run this block if the changes are not made by clearAllFilters()
        var filterWidget = $(this).closest('.filter-widget');
        updateFilterHeader(filterWidget);
        applyFilters("104"); // Apply filters based on current selections
        //console.log("Filter option changed and applied");

        // Toggle visibility of .filter-options
        $(this).closest('.filter-options').toggle();

        // Usage: Call this function with your specific .filter-options element
        const filterOptionsElement = $(this).closest('.filter-options');
        hideOnClickOutside(filterOptionsElement);    
      }
    });

    // Clear all selections button within each filter widget
    $('.filter-tags-clearall').off('click').on('click', function() {
      var filterWidget = $(this).closest('.filter-widget');
      clearFilterSelections(filterWidget);
      //console.log("Cleared all selections for widget:", filterWidget.attr('id'));
    });

    // Clear all selections within all filter widgets
    var isClearingAllFilters = false;
    function clearAllFilters() {
      isClearingAllFilters = true; // Set the flag to true before clearing filters
      $('.filter-widget').each(function() {
        clearFilterSelections($(this), "all");
        //console.log("Cleared all selections for widget:", $(this).attr('id'));
      });
      isClearingAllFilters = false; // Reset the flag after clearing filters
    }    

    // Clear state select filter
    $('.clear-state-filter').off('click').on('click', function() {
      //console.log("Clear state filter button clicked.");
      $('#state-select').val(null).trigger('change');
      applyFilters('clear state');
    });

    // Select2 event handling for the state dropdown
    $('.state-select').off('select2:select select2:unselect').on('select2:select', function(e) {
      //console.log("State selected:", $(this).val());
      applyFilters("126"); // Adjust this based on how you want to handle the selection
    }).on('select2:unselect', function() {
      //console.log("State unselected");
      applyFilters("129"); // Call filters without parameters or reset to default
    });

    // Clear map
    $('#clear-map').off('click').on('click', function() {
      //console.log("Clear map button clicked.");
      clearAllFilters();
      $('#state-select').val(null).trigger('change');
      applyFilters("181");
      resetMap();
    });    

  }

  // Function to get elements from the settings config
  function printKeyAndAttr(map_data, attr) {
    //console.log("Settings config: " + attr);
    // Get state elements
    for (var key in map_data) {
        if (map_data.hasOwnProperty(key)) {
            var attribute = map.fetchStateAttr(key, attr);
            //console.log("Key: " + key + ", " + attr + ": " + attribute);
        }
    }
    // Get point elements (Puerto Rico)
    var attribute = map.fetchPointAttr("p0", "tid");
    //console.log("Key: p0, tid: " + attribute);
  }

  // Call the function with your data and the attribute you want to fetch
  // printKeyAndAttr(map_cfg.map_data, 'tid');

  // Function to hide an element when clicked outside
  function hideOnClickOutside(element) {
    $(document).on('mouseup', function(e) {
      const container = $(element);
      // If the target of the click isn't the container nor a descendant of the container
      if (!container.is(e.target) && container.has(e.target).length === 0) {
        container.hide();
      }
    });
  }

  // Function to clear all selections within a filter widget
  function clearFilterSelections(filterWidget, source) {
    $(filterWidget).find('input[type=checkbox]:checked').prop('checked', false);
    updateFilterHeader(filterWidget); // Update the header to reflect the removal of selections
    if(source !== "all"){
      applyFilters("220"); // Re-apply filters to update the display according to the current selections
    }
  }

  //pull filter taxonomy terms from api endpoints and populate filters
  function populateFilters(endpoint, filterElementId) {
    //console.log("Calling populateFilters for: " + filterElementId);
    $.getJSON(endpoint, function(data) {
      // //console.log("Data received for " + filterElementId + ": ", data);

      // Sort the data alphabetically by the 'name' property
      data.sort((a, b) => {
        let nameA = a.name && typeof a.name === 'object' ? a.name[0].value : a.name;
        let nameB = b.name && typeof b.name === 'object' ? b.name[0].value : b.name;
        return nameA.localeCompare(nameB);
      });
      
      let optionsHtml = '';
      if (filterElementId === 'filter-state') {
        // //console.log("filterElementId: " + filterElementId);

        // Initialize the options with an empty option for the placeholder
        optionsHtml += '<option></option>'; // Add a blank option for the placeholder

        // Prepare HTML for state options
        data.forEach(item => {
          optionsHtml += `<option value="${item.tid}">${item.name}</option>`;
          // //console.log("beep");
        });
        // //console.log("optionsHtml: " + optionsHtml);
        // Directly append options to the existing select element
        $(`#${filterElementId} .state-select`).html(optionsHtml);
        //console.log("State options HTML prepared and appended.");

        // Initialize Select2 on the state selector after options have been appended
        $('.state-select').select2({
          placeholder: "Select a state",
          width: '100%', // Adjust the width as necessary
          allowClear: true // Allows a clear button that resets the state
        });
        // //console.log("Select2 initialized on state-select.");

      } else {
        // For other filters, use checkboxes and handle potentially nested item structure
        data.forEach(item => {
          let itemId = item.tid && typeof item.tid === 'object' ? item.tid[0].value : item.tid;
          let itemName = item.name && typeof item.name === 'object' ? item.name[0].value : item.name;
          let checkboxId = `${filterElementId}-${itemId}`;
          optionsHtml += `<div class="filter-option">
            <input type="checkbox" id="${checkboxId}" value="${itemId}" name="${filterElementId}[]">
            <label for="${checkboxId}">${itemName}</label>
          </div>`;
        });
        $('#' + filterElementId + ' .filter-options').html(optionsHtml);
        //console.log("Checkbox options HTML prepared and appended for " + filterElementId);
      }

      // Hide filter options initially
      $('#' + filterElementId + ' .filter-options').hide();
      initializeFilterWidgetListeners(); // Initialize event listeners after populating filters
    }).fail(function(jqXHR, textStatus, errorThrown) {
      console.error("Error fetching data for filters:", textStatus, errorThrown);
    });
  }
        
  // Initialize accordions and handle filter selections
  $('.filter-header').click(function() {
    $(this).siblings('.filter-options').slideToggle();
  });

  // Updating selections
  $('.filter-options input[type=checkbox]').change(function() {
    var filterWidget = $(this).closest('.filter-widget');
    //console.log("filter change detected > updateFilterHeader");
    updateFilterHeader(filterWidget);
  });
   
  // Initially bind the state tile custom click handler
  bindStateTileClickHandlers();
  
  // Enable state tile filter click handler
  function bindStateTileClickHandlers() {
    $('#map-container').on('click.myNamespace', 'path', function() {
        //console.log("#map-container:click.myNamespace");

        // 1. Find the corresponding state abbreviation for the clicked path element
        var stateAbbrev = findStateAbbreviation(this);
        //console.log("stateAbbrev.161: " + stateAbbrev);

        // 2. Pass the extracted value to the function getStateIdFromAbbrev("UT")
        var key = getStateIdFromAbbrev(stateAbbrev);
        //console.log("key.165: " + key);

        // 3. Pass that key to the function map.fetchStateAttr(key, 'tid') to get the tid that matches that state
        var tid = map.fetchStateAttr(key, 'tid');
        //console.log("tid.169: " + tid);

        // 4. Pass that key to the function map.fetchStateAttr(key, 'name') to get the state name that matches that state
        var name = map.fetchStateAttr(key, 'name');
        //console.log("name.173: " + name);

        // If only one state is being filtered, set the matching select option to 'selected' and trigger change event
        $('#state-select').val(tid);
        $('#state-select').trigger('change'); // trigger change event

        // 5. Then pass the name and tid values to the function applyFilters(line, tid, name)
        applyFilters('tile', tid, name);

        // After executing the new handler, unbind it
        $('#map-container').off('click.myNamespace', 'path');      
    });
  }

  // Check the value of the select list before each click
  $('#map-container').on('click', 'path', function() {
    //console.log("#map-container:click");
    var selectedStateTid = $('#state-select').val();
    //console.log("selectedStateId: " + selectedStateTid);

    // Find the corresponding state abbreviation for the clicked path element
    var stateAbbrev = findStateAbbreviation(this);
    //console.log("stateAbbrev.195: " + stateAbbrev);
      
    // 2. Pass the extracted value to the function getStateIdFromAbbrev("UT")
    var key = getStateIdFromAbbrev(stateAbbrev);
    //console.log("key.199: " + key);

    // 3. Pass that key to the function map.fetchStateAttr(key, 'tid') to get the tid that matches that state
    var tid = map.fetchStateAttr(key, 'tid');
    //console.log("tid.203: " + tid);

    // 4. Pass that key to the function map.fetchStateAttr(key, 'name') to get the state name that matches that state
    var name = map.fetchStateAttr(key, 'name');
    //console.log("name.207: " + name);

    if (selectedStateTid !== tid) { // a different state was clicked
        // Trigger your new event handler
        //console.log("trigger.211");
        // Bind custom state tile filter click handler again
        bindStateTileClickHandlers();

        $(this).trigger('click.myNamespace');
    }
  });

  // Function to find the state abbreviation based on path element's coordinates
  function findStateAbbreviation(path) {
    const pathBBox = path.getBBox();
    const xCenter = pathBBox.x + pathBBox.width / 2;
    const yCenter = pathBBox.y + pathBBox.height / 2;

    let stateAbbreviation = "";

    $('text').each(function() {
        const textX = parseFloat($(this).attr('x'));
        const textY = parseFloat($(this).attr('y'));
        
        // Assuming the text is centered within the path's bounding box
        if (Math.abs(textX - xCenter) < 1 && Math.abs(textY - yCenter) < 1) {
            stateAbbreviation = $(this).find('tspan').text();
        }
    });

    return stateAbbreviation;
  }

  function updateFilterHeader(filterWidget) {
    var selectedOptions = filterWidget.find('input[type=checkbox]:checked, input[type=radio]:checked');
    var tagsContainer = filterWidget.find('.filter-tags');
    var selectTextSpan = filterWidget.find('.filter-tags-inner-text');
    tagsContainer.empty();

    if (selectedOptions.length > 0) {
      // Hide "Select ..." text when one or more filters are selected
      selectTextSpan.hide();
    } else {
      // Show "Select ..." text when no filters are selected
      selectTextSpan.show();
    }

    selectedOptions.each(function() {
      var labelForInput = $("label[for='" + $(this).attr('id') + "']").text();
      var tagHtml = `<span class="filter-tag"><span class="filter-term"><span class="filter-term-label">${labelForInput}</span></span><span class="close" data-id="${this.id}"></span></span>`;
      tagsContainer.append(tagHtml);
    });
  }

  //de-select checkboxes on filter 'x' click
  $(document).on('click', '.filter-tag .close', function() {
    var checkboxId = $(this).data('id');
    $('#' + checkboxId).prop('checked', false).trigger('change');
  });
    
  // Call populateFilters for each filter widget
  populateFilters('/api/topics', 'filter-topics');
  populateFilters('/api/targets', 'filter-targets');
  populateFilters('/api/grades', 'filter-grades');
  populateFilters('/api/states', 'filter-state'); 

  // Filtering logic
  function applyFilters(line, tid, name) {
    //console.log("applyFilters: initiated on line: " + line);

    if(line === 'tile'){
      //console.log("State tile clicked: " + name + "(" + tid + ")");

      var state = tid;
      var stateText = name;  // Retrieve the full text of the selected state option

      var topics = $('input[name="filter-topics[]"]:checked').map(function() {
        return $(this).val();
      }).get();

      var targets = $('input[name="filter-targets[]"]:checked').map(function() {
          return $(this).val();
      }).get();

      var grades = $('input[name="filter-grades[]"]:checked').map(function() {
          return $(this).val();
      }).get();

    } else {

      var state = $('#state-select').val() || 'all';
      var stateText = $('#state-select option:selected').text();  // Retrieve the full text of the selected state option
  
      var topics = $('input[name="filter-topics[]"]:checked').map(function() {
          return $(this).val();
      }).get();
  
      var targets = $('input[name="filter-targets[]"]:checked').map(function() {
          return $(this).val();
      }).get();
  
      var grades = $('input[name="filter-grades[]"]:checked').map(function() {
          return $(this).val();
      }).get();
  
    }

    var isOnlyStateFiltered = !topics.length && !targets.length && !grades.length && (state !== 'all');
    //console.log("isOnlyStateFiltered: " + isOnlyStateFiltered);
    //console.log("state: " + state);
    var isStateFiltered = (state !== 'all') && !isOnlyStateFiltered;
    //console.log("isStateFiltered: " + isStateFiltered);

    $.ajax({
        url: '/custom-js-map/update-view',
        type: 'GET',
        data: { state: state, topics: topics.join(','), targets: targets.join(','), grades: grades.join(',') },
        success: function(response) {
            if(response && response.content) {
                // //console.log("response.content: <p>" + response.content);
                $('#filter-results').html(response.content);
                Drupal.attachBehaviors($('#filter-results')[0]);

                if (response.stateData) {
                  //console.log("stateData being passed to updateMapData:", response.stateData);

                  updateMapData(response.stateData, isOnlyStateFiltered, isStateFiltered, state);
                  // printKeyAndAttr(map_cfg.map_data, 'tid');
                  if (isOnlyStateFiltered) {
                    $('.view-header-title').html(`Number of studies in <strong>${stateText}</strong>`);
                  }
                  if (isStateFiltered) {
                    $('.view-header-title').html(`Matching studies in <strong>${stateText}</strong>`);
                  }

                  // Replace 'http://' with 'https://' to avoid mixed content error
                  $(".view-state-studies .feed-icons .feed-icon").each(function() {
                    var href = $(this).attr("href");
                    if (href.startsWith("http://")) {
                        $(this).attr("href", href.replace("http://", "https://"));
                    }
                  });

                } else {
                  console.error("No stateData found in the response");
                  resetMap(); // Reset map to defaults
                }
                
                if(response.nodeCount > 4) { //more than 4 nodes returned from view
                  // Construct the "More" link using the stateText for the URL
                  var moreLinkQueryString = formatQueryStringForMoreLink(state, stateText, topics, targets, grades);
                  var moreLinkUrl = '/state-studies?' + moreLinkQueryString;
                  var moreLinkHtml = '<div class="more-link"><a href="' + moreLinkUrl + '" class="btn btn-primary">View More</a></div>';
                  $('.view-footer').before(moreLinkHtml);
                  $('.view-state-studies .feed-icons').addClass("hide"); //hide the download CSV link
                }

              } else {
                console.error("Invalid response format or empty content");
                $('#filter-results').html('No results found.');
                resetMap(); // Reset map to defaults
                if (isOnlyStateFiltered) {
                  //console.log("isOnlyStateFiltered 342: " + isOnlyStateFiltered);
                  if(stateText === "Puerto Rico"){

                    let pointId = "p0";
                    // Set state tile active even though no results for this state (PR)
                    let commentHtml = `<div class='state-tooltip'><div class='state-tooltip-title'>${stateText}</div><div class='state-tooltip-count'>Total # of studies: 0</div><div class='state-tooltip-link'><a href="/state-profiles/esser-plans?state=${state}">See ESSER Plan</a></div></div>`;
                    map.setPointAttr(pointId, {
                      comment: commentHtml,
                      color: '#8352B7', // Set the active color
                      nameColor: '#ffffff'
                    });  
                    map.reloadMap(); // Redraw map with updated data
                    checkAndReplaceTargetGElement(1); // Update any custom SVG modifications
                  } else {

                    let stateId = getStateIdFromName(stateText);
                    // Set state tile active even though no results for this state
                    let commentHtml = `<div class='state-tooltip'><div class='state-tooltip-title'>${stateText}</div><div class='state-tooltip-count'>Total # of studies: 0</div><div class='state-tooltip-link'><a href="/state-profiles/esser-plans?state=${state}">See ESSER Plan</a></div></div>`;
                    map.setStateAttr(stateId, {
                      comment: commentHtml,
                      color: '#8352B7', // Set the active color
                      nameColor: '#ffffff'
                    });  
                    map.reloadMap(); // Redraw map with updated data
                    checkAndReplaceTargetGElement(0); // Update any custom SVG modifications
                  }
                }

            }
        },
        error: function(xhr, status, error) {
            console.error("Failed to fetch data:", status, error);
        }
    });

    //console.log("Filters applied.");
  }
    
  // Event handler to listen for filter option changes
  // $('#filter-widgets').on('change', '.filter-options input[type=checkbox]', function() {
  //   //console.log("Filter option changed.");
  //   applyFilters("312");
  // });

  // Add logic for tag removal which also calls applyFilters()
  $(document).on('click', '.filter-tag .close', function() {
    var checkboxId = $(this).parent().data('checkbox-id');
    $('#' + checkboxId).prop('checked', false);
    //console.log("checkboxID: " + checkboxId);
    applyFilters("344");
  });

  function updateMapData(stateData, isOnlyStateFiltered, isStateFiltered, selectedStateTid) {
    //console.log("Received stateData:", stateData);

    //hide the map legend
    $("#map-filtered-legend").addClass('hide');

    // Prepare to count studies for each state
    let stateCounts = {};

    // Count the number of occurrences for each state `tid`
    stateData.forEach(state => {
      if (state.tid in stateCounts) {
        stateCounts[state.tid].count++;
      } else {
        stateCounts[state.tid] = {
          count: 1,
          name: state.name
        };
      }
    });

    //console.log("Mapped stateCounts:", stateCounts);
    //console.log("isOnlyStateFiltered: " + isOnlyStateFiltered);
    //console.log("isStateFiltered: " + isStateFiltered);
    //console.log("selectedStateTid: " + selectedStateTid);
    // printKeyAndAttr(map_cfg.map_data, 'tid');

    // Initialize counter
    let totalStates = -1; //starts with -1 to not count selected state
    // Update the map for each state using its 'tid'
    Object.entries(stateCounts).forEach(([tid, data]) => {
      totalStates++; // Increment the counter
      let stateName = data.name;
      let count = data.count;

      // Retrieve the state ID from the map settings using the state name
      let stateId = getStateIdFromName(stateName);
      //console.log(`Updating map for stateName: ${stateName} with count: ${count}, corresponding stateId: ${stateId}, and tid: ${tid}`);
      if (stateId) {
        if (isOnlyStateFiltered && tid !== selectedStateTid) {
          // If only one state is being filtered and this is not the selected state,
          // set the map attributes to the default values
          map.setStateAttr(stateId, {
            comment: "",
            color: '#D1D5DB', // Default color
            nameColor: "#000000" // Default name color
          });
        } else if (isStateFiltered && tid !== selectedStateTid) {
          // If a state is being filtered along with other filters, and this is not the selected state,
          // set the map attributes to the alternate values
          let commentHtml = `<div class='state-tooltip'><div class='state-tooltip-title'>${stateName}</div><div class='state-tooltip-count'>Total # of studies: ${count}</div><div class='state-tooltip-link'><a href='/state-studies?state=${tid}' title='See matching studies for this state.'>See matching studies</a></div><div class='state-tooltip-link'><a href="/state-profiles/esser-plans?state=${tid}">See ESSER Plan</a></div></div>`;
          map.setStateAttr(stateId, {
            comment: commentHtml,
            color: '#E2BDE4', // Alternate color
            nameColor: "#000000" // Default name color
          });
          // Set the inner HTML of the legend
          $("#map-filtered-legend .legend-item.included").html(`${totalStates} Other states included in matching studies`);        
          //show the map legend
          $("#map-filtered-legend").removeClass('hide');
        } else {
          // Otherwise, set the map attributes for this state
          let commentHtml = `<div class='state-tooltip'><div class='state-tooltip-title'>${stateName}</div><div class='state-tooltip-count'>Total # of studies: ${count}</div><div class='state-tooltip-link'><a href='/state-studies?state=${tid}' title='See matching studies for this state.'>See matching studies</a></div><div class='state-tooltip-link'><a href="/state-profiles/esser-plans?state=${tid}">See ESSER Plan</a></div></div>`;
          map.setStateAttr(stateId, {
            comment: commentHtml,
            color: '#8352B7', // Set the active color
            nameColor: '#ffffff'
          });
        }
      }
    });

    // Optionally, reset states that were not mentioned in the response
    Object.keys(map_cfg.map_data).forEach(key => {
      if (!(map_cfg.map_data[key].tid in stateCounts)) {
        map.setStateAttr(key, {
          comment: "",
          color: '#D1D5DB', // Default color
          nameColor: "#000000" // Default name color
        });
      }
    });

    map.reloadMap(); // Redraw map with updated data
    checkAndReplaceTargetGElement(); // Update any custom SVG modifications
  }
  // Initialize and bind events
  initializeFilterWidgetListeners();

  //adds class to state-studies modal for css targeting
  $('.ui-dialog').each(function() {
      if ($(this).find('.state-studies').length > 0) {
          $(this).addClass('study-modal');
      }
  });

  // Helper function to reset all state tiles to defaults
  function resetMap() {
    //console.log("resetMap");
    //hide the map legend
    $("#map-filtered-legend").addClass('hide');

    //reset the state tiles
    Object.keys(map_cfg.map_data).forEach(key => {
      // //console.log("reset state tile: " + key);
      map.setStateAttr(key, {
        comment: "",
        color: '#D1D5DB', // Default color
        nameColor: "#000000" // Default name color
      });
    });

    //reset the point tiles (Puerto Rico)
    Object.keys(map_cfg.points).forEach(key => {
      // //console.log("reset point tile: " + key);
      map.setPointAttr("p0", {
        comment: "",
        color: '#D1D5DB', // Default color
        nameColor: "#000000" // Default name color
      });
    });
    map.reloadMap(); // Redraw map with updated data
    checkAndReplaceTargetGElement(0); // Update any custom SVG modifications
  }
    
  //helper function to format query parameters for passing to /state-studies
  function formatQueryStringForMoreLink(stateId, stateText, topics, targets, grades) {
    var params = [];

    if (stateId !== 'all') params.push("state=" + stateId);
    topics.forEach(function(topic) {
        params.push("topics[" + topic + "]=" + topic);
    });
    targets.forEach(function(target) {
        params.push("targets[" + target + "]=" + target);
    });
    grades.forEach(function(grade) {
        params.push("grades[" + grade + "]=" + grade);
    });

    return params.join('&');
  }
  
});