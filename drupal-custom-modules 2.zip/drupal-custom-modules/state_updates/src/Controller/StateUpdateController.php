<?php

namespace Drupal\state_updates\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class StateUpdateController extends ControllerBase {

  protected $logger;

  public function __construct(LoggerChannelFactoryInterface $logger_factory) {
    $this->logger = $logger_factory->get('state_updates');
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('logger.factory')
    );
  }

  public function updateStateReferences() {
    $nids = \Drupal::entityQuery('node')
      ->accessCheck(FALSE)
      ->condition('type', 'state_studies')
      ->execute();
    $parent_nodes = Node::loadMultiple($nids);

    $processed_count = 0;
    foreach ($parent_nodes as $parent_node) {
      if ($this->processParentNode($parent_node->id())) {
        $processed_count++;
      }
    }

    $message = \Drupal::translation()->formatPlural(
      $processed_count,
      'One node processed.', '@count nodes processed.'
    );
    \Drupal::messenger()->addMessage($message);

    $this->logger->info('Processed @count nodes.', ['@count' => $processed_count]);

    return [
      '#markup' => $message,
    ];
  }

  public function processParentNode($parent_nid) {
    $parent_node = Node::load($parent_nid);
    if (!$parent_node) {
        $this->logger->error('Parent node not loaded: @nid', ['@nid' => $parent_nid]);
        return false;
    }
    $parent_artifact_value = $parent_node->field_artifact_study_pk->value;

    $child_nids = \Drupal::entityQuery('node')
      ->accessCheck(FALSE)
      ->condition('type', 'state_profile_studies')
      ->condition('field_artifact_study', $parent_artifact_value)
      ->execute();

    if (empty($child_nids)) {
        $this->logger->info('No child nodes found for parent @nid with artifact value @value', ['@nid' => $parent_nid, '@value' => $parent_artifact_value]);
        return false;
    }

    $child_nodes = Node::loadMultiple($child_nids);
    $term_ids_states = [];
    $term_ids_topics = [];
    $term_ids_population = [];
    $term_ids_grade_level = [];

    // Aggregating term IDs from different fields
    foreach ($child_nodes as $child_node) {
        foreach ($child_node->field_2_states->getValue() as $item) {
            $term_ids_states[] = $item['target_id'];
        }
        foreach ($child_node->field_1_topic->getValue() as $item) {
            $term_ids_topics[] = $item['target_id'];
        }
        foreach ($child_node->field_5_target_population->getValue() as $item) {
            $term_ids_population[] = $item['target_id'];
        }
        foreach ($child_node->field_3_grade_level->getValue() as $item) {
            $term_ids_grade_level[] = $item['target_id'];
        }
    }

    // Removing duplicates and saving to the parent node
    $parent_node->field_states = array_unique($term_ids_states);
    $parent_node->field_study_topics = array_unique($term_ids_topics);
    $parent_node->field_study_target_population = array_unique($term_ids_population);
    $parent_node->field_study_grade_level = array_unique($term_ids_grade_level);

    $parent_node->save();

    $this->logger->info('Updated node @nid with terms: @terms', ['@nid' => $parent_node->id(), '@terms' => implode(', ', $term_ids_states)]);
    return true;
  }
}
